-- name: [CS] Leah The Bnuey
-- description: Ya gotta believe!\n\n\\#ff7777\\This Pack requires Character Select\nto use as a Library!

--[[
    API Documentation for Character Select can be found below:
    https://github.com/Squishy6094/character-select-coop/blob/main/API-doc.md

    Use this if you're curious on how anything here works >v<
]]

local E_MODEL_LEAH = smlua_model_util_get_id("Leah_geo")

local TEX_LEAH_ICON = get_texture_info("leah-icon")

local TEXT_MOD_NAME = "Leah"

local VOICETABLE_LEAH = {
    [CHAR_SOUND_ATTACKED] = 'baba_crunch.ogg',
    [CHAR_SOUND_DOH] = 'baba_hurt.ogg',
    [CHAR_SOUND_DROWNING] = 'baba_crunch.ogg',
    [CHAR_SOUND_DYING] = 'baba_die.ogg',
	[CHAR_SOUND_EEUH] = 'baba_noisema2.ogg',
    [CHAR_SOUND_GROUND_POUND_WAH] = 'baba_noisema.ogg',
    [CHAR_SOUND_HAHA] = 'baba_what.ogg',
    [CHAR_SOUND_HAHA_2] = 'baba_what2.ogg',
    [CHAR_SOUND_HERE_WE_GO] = 'baba_win.ogg',
    [CHAR_SOUND_HOOHOO] = 'baba_noisema.ogg',
	[CHAR_SOUND_HRMM] = 'baba_sweep.ogg',
	[CHAR_SOUND_IMA_TIRED] = 'baba_sleepy.ogg',
	[CHAR_SOUND_LETS_A_GO] = 'baba_letsago.ogg',
    [CHAR_SOUND_MAMA_MIA] = 'baba_noise2.ogg',
    [CHAR_SOUND_OKEY_DOKEY] = 'baba_letsago.ogg',
    [CHAR_SOUND_ON_FIRE] = 'baba_burn.ogg',
    [CHAR_SOUND_OOOF] = 'baba_crunch.ogg',
    [CHAR_SOUND_OOOF2] = 'baba_sweep.ogg',
    [CHAR_SOUND_PUNCH_HOO] = 'baba_noisema.ogg',
    [CHAR_SOUND_PUNCH_WAH] = 'baba_noisema2.ogg',
    [CHAR_SOUND_PUNCH_YAH] = 'baba_noisema3.ogg',
    [CHAR_SOUND_SO_LONGA_BOWSER] = 'baba_bowser.ogg',
    [CHAR_SOUND_TWIRL_BOUNCE] = 'baba_strange.ogg',
	[CHAR_SOUND_UH] = 'baba_selectma.ogg',
    [CHAR_SOUND_UH2] = 'baba_selectma.ogg',
    [CHAR_SOUND_UH2_2] = 'baba_selectma.ogg',
    [CHAR_SOUND_WAAAOOOW] = 'baba_sweep.ogg',
    [CHAR_SOUND_WAH2] = 'baba_noisema2.ogg',
    [CHAR_SOUND_WHOA] = 'baba_sweep.ogg',
    [CHAR_SOUND_YAHOO] = 'baba_awesome.ogg',
    [CHAR_SOUND_YAHOO_WAHA_YIPPEE] = 'baba_level_select.ogg',
    [CHAR_SOUND_YAH_WAH_HOO] = 'baba_noise.ogg',
    [CHAR_SOUND_YAWNING] = 'baba_noise2.ogg',
}

local PALETTE_LEAH = {
    [PANTS]  = "0F2B6C",
    [SHIRT]  = "5E98E4",
    [GLOVES] = "FFFFFF",
    [SHOES]  = "DE2919",
    [HAIR]   = "000000",
    [SKIN]   = "FEFDCC",
    [CAP]    = "f48379",
}

--[[ LEAH does NOT take his hat off under ANY circumstances, as canonically, hatless LEAH is a horrid sight.
local CAPTABLE_LEAH = {
    normal = smlua_model_util_get_id("LEAH_cap_normal_geo"),
    wing = smlua_model_util_get_id("LEAH_cap_wing_geo"),
    metal = smlua_model_util_get_id("LEAH_cap_metal_geo"),
    metalWing = smlua_model_util_get_id("LEAH_cap_wing_geo"),
}
--]]
if _G.charSelectExists then
    CT_CHAR = _G.charSelect.character_add("Leah", "A Bnuey", "Bnuey", {r = 247, g = 133, b = 122}, E_MODEL_LEAH, CT_MARIO, TEX_LEAH_ICON)
--      _G.charSelect.character_add_caps(E_MODEL_LEAH, CAPTABLE_LEAH)

    _G.charSelect.character_add_palette_preset(E_MODEL_LEAH, PALETTE_LEAH)

     --the following must be hooked for each character added

    _G.charSelect.character_add_voice(E_MODEL_LEAH, VOICETABLE_LEAH)
    hook_event(HOOK_CHARACTER_SOUND, function (m, sound)
        if _G.charSelect.character_get_voice(m) == VOICETABLE_LEAH then return _G.charSelect.voice.sound(m, sound) end
    end)
    hook_event(HOOK_MARIO_UPDATE, function (m)
        if _G.charSelect.character_get_voice(m) == VOICETABLE_LEAH then return _G.charSelect.voice.snore(m) end
    end)
else
    djui_popup_create("\\#ffffdc\\\n"..TEXT_MOD_NAME.."\nRequires the Character Select Mod\nto use as a Library!\n\nPlease turn on the Character Select Mod\nand Restart the Room!", 6)
end
